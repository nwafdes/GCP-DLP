import base64, json, logging, functions_framework
from download_file import download_gcs_object

logging.basicConfig(level=logging.INFO)

@functions_framework.cloud_event
def handle_pubsub_cloudevent(event) -> None:
    msg = (event.data or {}).get("message", {}) or {}
    attrs = msg.get("attributes") or {}
    bucket = attrs.get("bucketId")
    object_id = attrs.get("objectId")

    content_type = None
    if msg.get("data"):
        meta = json.loads(base64.b64decode(msg["data"]))
        content_type = meta.get("contentType")
        bucket = bucket or meta.get("bucket")
        object_id = object_id or meta.get("name")

    try:
        file_info = download_gcs_object(bucket, object_id)  # or dest_path="/tmp/file"
    except:
        logging.exception("You don't have enough permissions to download the file")
    
    logging.info("Downloaded %s (%s) %sB", file_info["object"], file_info["content_type"], file_info["size"])
