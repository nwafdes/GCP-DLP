from typing import Optional
from google.cloud import storage
from google.api_core.exceptions import NotFound, Forbidden

_storage = storage.Client()  # reuse across invocations

def download_gcs_object(bucket: str, object_id: str, dest_path: Optional[str] = None,
                        client: storage.Client = _storage):
    blob = client.bucket(bucket).get_blob(object_id)
    if not blob:
        raise FileNotFoundError(f"Object not found: gs://{bucket}/{object_id}")
    data = blob.download_as_bytes()
    result = {"bucket": bucket, "object": object_id, "content_type": blob.content_type, "size": len(data)}
    if dest_path:
        import os; os.makedirs(os.path.dirname(dest_path), exist_ok=True)
        with open(dest_path, "wb") as f: f.write(data)
        result["path"] = dest_path
    else:
        result["bytes"] = data
    return result
